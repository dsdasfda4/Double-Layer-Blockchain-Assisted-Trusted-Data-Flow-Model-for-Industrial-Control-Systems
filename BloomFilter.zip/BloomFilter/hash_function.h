﻿//
// Created by wyd on 2024/5/16.
//

#ifndef BLOOMFILTER_HASH_FUNCTION_H
#define BLOOMFILTER_HASH_FUNCTION_H

unsigned int SDBMHash(const char *str);
unsigned int RSHash(const char *str);
unsigned int JSHash(const char *str);
unsigned int PJWHash(const char *str);
unsigned int APHash(const char *str);
unsigned int DJBHash(const char *str);
unsigned int ELFHash(const char *str);
unsigned int BKDRHash(const char *str);

#endif //BLOOMFILTER_HASH_FUNCTION_H
