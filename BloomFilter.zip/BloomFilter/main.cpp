﻿#include <iostream>
#include <chrono>
#include <Windows.h>
#include <vector>
#include <random>


#include "bloom_filter.h"

double GetMicrosecondsTimestamp()
{
    LARGE_INTEGER frequency;
    LARGE_INTEGER counter;

    // 获取计时器的频率
    QueryPerformanceFrequency(&frequency);

    // 获取当前计时器的值
    QueryPerformanceCounter(&counter);

    // 将计时器的值转换为微秒
    double microseconds = (double)counter.QuadPart / frequency.QuadPart * 1000000.0;

    return microseconds;
}

// 将时间间隔转换为毫秒
long long get_timestamp_millis() {
    auto now = std::chrono::system_clock::now();
    auto duration_since_epoch = now.time_since_epoch();
    auto millis_since_epoch = std::chrono::duration_cast<std::chrono::milliseconds>(duration_since_epoch).count();
    return millis_since_epoch;
}

// 计算两个时间戳之间的时间间隔（毫秒）
long long calculate_time_difference_millis(long long timestamp1, long long timestamp2) {
    return std::abs(timestamp1 - timestamp2);
}


int main()
{
    std::string filePath = "D:\\vscode_space\\GenerateHash\\build-GenerateHash-Desktop_x86_windows_msvc2017_pe_64bit-Debug\\hash_file.txt";

    // 创建一个输入文件流对象
    std::ifstream fileStream(filePath);

    // 检查文件是否成功打开
    if (!fileStream) {
        std::cerr << "无法打开文件: " << filePath << std::endl;
        return 1;
    }

    std::vector<std::string> hash_vec;
    // 读取文件内容
    std::string line;
    while (std::getline(fileStream, line)) {
        hash_vec.emplace_back(line);
    }

    // 关闭文件流
    fileStream.close();

    int all_num = 60000;

    BloomFilter mybloom(0.01,all_num);
    mybloom.filterInit();
    mybloom.arrayGenerate(filePath);
    std::cout<<"intNum:"<<mybloom.getIntNum()<<", hashFunNum:"<<mybloom.getHashFunNum() << ", bitNum: " << mybloom.getBitNum() <<std::endl;

    double max_time = 0;

    double min_time = 0;

    double sum_time = 0;

    std::string diff_str = "5d50e449dbadee241f526621350b0807384085d03fa37014afa004090e4d26c3";

    double timestamp = GetMicrosecondsTimestamp();
    for (const auto &item : hash_vec)
    {
        if (item == diff_str)
            break;
    }
    double timestamp2 = GetMicrosecondsTimestamp();

    double ergodic_time = timestamp2 - timestamp;
//    for (int i = 0; i < 100; i++)
//    {
//        // 创建一个随机数引擎
//        std::random_device rd;
//        std::mt19937 gen(rd());
//
//        // 创建一个在[1, 10000]范围内的均匀分布
//        std::uniform_int_distribution<> dis(0, all_num - 1);
//
//        // 生成一个随机数
//        int random_num = dis(gen);

//        std::cout << "random_num: " << random_num << std::endl;

        double timestamp3 = GetMicrosecondsTimestamp();
        mybloom.isContain(diff_str.c_str());
        double timestamp4 = GetMicrosecondsTimestamp();
//        std::cout << "timestamp: " << timestamp2 - timestamp << std::endl;
        double time_not_have = timestamp4 - timestamp3;
//        if (i == 0)
//        {
//            max_time = time_diff;
//            min_time = time_diff;
//        }
//        else
//        {
//            if (time_diff > max_time)
//                max_time = time_diff;
//
//            if (time_diff < min_time)
//                min_time = time_diff;
//        }
//
//        sum_time += time_diff;
//    }

    std::cout << "all_num: " << all_num << std::endl;
//    std::cout << "max_time: " << max_time << std::endl;
//    std::cout << "min_time: " << min_time << std::endl;
    std::cout << "ergodic_time: " << ergodic_time << std::endl;
    std::cout << "time_not_have: " << time_not_have << std::endl;

    return 0;
}
