﻿//
// Created by wyd on 2024/5/16.
//

#ifndef BLOOMFILTER_BLOOM_FILTER_H
#define BLOOMFILTER_BLOOM_FILTER_H

#include <stdio.h>
#include <iostream>
#include <string>
#include <math.h>
#include <vector>
#include <fstream>
#include "hash_function.h"

#define INT_SIZE 32
#define BUFFER_SIZE 1024

class BloomFilter
{
public:
    //样本个数n，期望的失误率p，传入样本的文档路径
    BloomFilter(double errRate,int sampleNum);
    ~BloomFilter();
    void filterInit();                      //初始化布隆过滤器
    void arrayGenerate(std::string path);   //打开path路径的文档，计算每一行样本到array中
    bool isContain(const char* str);        //查看字符串是否在样本中存在
    void storeArray(std::string path);      //把array存储在指定路径文件path里
    void restoreArray(std::string path);    //把array从指定路径文件path里恢复载入
    int getHashFunNum();                    //返回需要的哈希函数的个数k
    int getIntNum();                        //返回需要的内存的int数
    int getBitNum();
private:
    int hashtableInit();    //把几个哈希函数加入到hastable中
    std::string path;       //传入样本的文档路径
    double errRate;         //样本失误率p
    int sampleNum;          //样本个数n
    int bitNum;             //需要的二进制位数m
    int intNum;             //需要申请内存的int数
    int hashFunNum;         //需要的哈希函数的个数k,注意计算得到的哈希函数个数k应该<=hashtable.size();
    int *array;             //内存
    std::vector<unsigned int (*)(const char*)> hashtable;    //存放计算字符串哈希值的哈希函数
};


#endif //BLOOMFILTER_BLOOM_FILTER_H
